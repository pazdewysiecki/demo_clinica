var $ = jQuery.noConflict();

function listadousaurios(){
            $.ajax({
                url: "/usuarios/listar_usuarios/",
                type:"get",
                dataType: "json",
                succes: function(response){
                    console.log(response)
                },
                error: function(error){
                    console.log(error);
                }
            })
        }

        $(document).ready(function (){
            listadousaurios();
        });

