from django.apps import AppConfig


class TramitesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tramites'
