from ast import Try
from http import client
from multiprocessing import context
from pydoc import cli
from django.shortcuts import redirect, render
from django.core.exceptions import ObjectDoesNotExist
from django.db.models import Q
from django.urls import reverse_lazy
from django.views.generic import TemplateView,ListView, UpdateView, CreateView, DeleteView
from django.views.generic.edit import CreateView
from django.urls import reverse_lazy 
from .forms import ClientesForm,TramitesForm,Clientes_TramitesForm, CedulasForm, CasillerosForm
from .models import Casilleros3, Clientes, Clientes_Tramites, Tramites, Cedulas1
from django.core.paginator import Paginator

#Clase para inciar#

class Inicio(TemplateView):
    template_name = 'index.html'

class InicioSistema(TemplateView):
    template_name = 'home.html'

    """
    def home(request):
        queryset = request.GET.get("buscar")
        posts = Clientes_Tramites.objects.filter(Autos = 'autos' )
        if queryset:
            posts = Clientes_Tramites.objects.filter(
                Q( cliente_id__icontains = queryset) |
                Q( tramite_id__icontains = queryset) |
                Q( autos__icontains = queryset)
            ).distinct()
        return render(request, 'index.html', {'posts': posts})
"""


#Clases para Clientes#

class ListarClientes(ListView):
    model = Clientes
    template_name = 'tramites/listar_clientes.html'
    context_object_name = 'clientes'
    queryset = Clientes.objects.all()


class EditarClientes(UpdateView):
    model = Clientes
    template_name = 'tramites/modalclientes.html'
    form_class = ClientesForm
    success_url = reverse_lazy ('tramites:listar_clientes')


class CrearClientes(CreateView):
    model = Clientes
    form_class = ClientesForm
    template_name = 'tramites/crear_clientes.html'
    success_url = reverse_lazy ('tramites:listar_clientes')

class CrearModalClientes(CreateView):
    model = Clientes
    template_name = 'tramites/modalcrearclientes.html'
    form_class = ClientesForm
    success_url = reverse_lazy ('tramites:listar_clientes')

class EliminarClientes(DeleteView):
    model = Clientes
    success_url = reverse_lazy ('tramites:listar_clientes')


def buscar_clientes(request):
        busqueda = request.GET.get("buscar")
        clientes = Clientes.objects.all()
        
        if busqueda:
            clientes = Clientes.objects.filter(
                Q (nombre_cliente__icontains = busqueda) |
                Q (mail_cliente__icontains= busqueda) |
                 Q (id__icontains= busqueda)
            ).distinct()
        return render(request, 'tramites/listar_clientes.html', {'clientes':clientes})




#Clases para Tramites#

class ListarTramites(ListView):
    model = Tramites
    template_name = 'tramites/listar_tramites.html'
    context_object_name = 'tramites'
    queryset = Tramites.objects.all()

def buscar_tramites(request):
        busqueda = request.GET.get("buscar")
        tramites = Tramites.objects.all()

        if busqueda:
            tramites = Tramites.objects.filter(
                Q (nombre_tramite__icontains = busqueda) |
                Q (id__icontains = busqueda)
            ).distinct()
        return render(request, 'tramites/listar_tramites.html', {'tramites':tramites})

class EditarTramites(UpdateView):
    model = Tramites
    template_name = 'tramites/modaltramites.html'
    form_class = TramitesForm
    success_url = reverse_lazy ('tramites:listar_tramites')

class CrearTramites(CreateView):
    model = Tramites
    form_class = TramitesForm
    template_name = 'tramites/crear_tramites.html'
    success_url = reverse_lazy ('tramites:listar_tramites')

class CrearModalTramites(CreateView):
    model = Tramites
    template_name = 'tramites/modalcreartramites.html'
    form_class = TramitesForm
    success_url = reverse_lazy ('tramites:listar_tramites')

class EliminarTramites(DeleteView):
    model = Tramites
    success_url = reverse_lazy ('tramites:listar_tramites')


#Clases para Casillero#

class ListarCasilleros(ListView):
    model = Casilleros3
    template_name = 'tramites/listar_casilleros.html'
    context_object_name = 'casilleros'
    queryset = Casilleros3.objects.all()


class EditarCasilleros(UpdateView):
    model = Casilleros3
    template_name = 'tramites/modalcasilleros.html'
    form_class = CasillerosForm
    success_url = reverse_lazy ('tramites:listar_casilleros')


class CrearCasilleros(CreateView):
    model = Casilleros3
    form_class = CasillerosForm
    template_name = 'tramites/crear_casilleros.html'
    success_url = reverse_lazy ('tramites:listar_casilleros')

class CrearModalCasilleros(CreateView):
    model = Casilleros3
    template_name = 'tramites/modalcrearcasilleros.html'
    form_class = CasillerosForm
    success_url = reverse_lazy ('tramites:listar_casilleros')

class EliminarCasilleros(DeleteView):
    model = Casilleros3
    success_url = reverse_lazy ('tramites:listar_casilleros')


def buscar_casilleros(request):
        busqueda = request.GET.get("buscar")
        casilleros = Casilleros3.objects.all()
        

        if busqueda:
            casilleros = Casilleros3.objects.filter(
                Q (cliente_id__nombre_cliente__icontains = busqueda) |
                Q (cliente_id__id__icontains = busqueda) |
                Q (casillero__icontains= busqueda) |
                Q (co_titulares__icontains= busqueda) |
                 Q (autorizados_a_retirar__icontains= busqueda)
            ).distinct()
        return render(request, 'tramites/listar_casilleros.html', {'casilleros':casilleros})




#Clases para ClientesTramites#

class ListarClientes_Tramites(ListView):
    model = Clientes_Tramites
    template_name = 'tramites/listar_clientes_tramites.html'
    context_object_name = 'clientes_tramites'
    queryset = Clientes_Tramites.objects.all()
    

class EditarClientes_Tramites(UpdateView):
    model = Clientes_Tramites
    template_name = 'tramites/modalClientes_tramites.html'
    form_class = Clientes_TramitesForm
    success_url = reverse_lazy ('tramites:listar_clientes_tramites')


class CrearClientes_Tramites(CreateView):
    model = Clientes_Tramites
    form_class = Clientes_TramitesForm
    template_name = 'tramites/crear_clientes_tramites.html'
    success_url = reverse_lazy ('tramites:listar_clientes_tramites')

class CrearModalClientes_Tramites(CreateView):
    model = Clientes_Tramites
    template_name = 'tramites/modalcrearclientes_tramites.html'
    form_class = Clientes_TramitesForm
    success_url = reverse_lazy ('tramites:listar_clientes_tramites')
    

class EliminarClientes_Tramites(DeleteView):
    model = Clientes_Tramites
    success_url = reverse_lazy ('tramites:listar_clientes_tramites')


def buscar_clientes_tramites(request):
        busqueda = request.GET.get("buscar")
        clientes_tramites = Clientes_Tramites.objects.all()
        """
        def listing(request):
                contact_list = Clientes_Tramites.objects.all()
                paginator = Paginator(contact_list, 2) # Show 25 contacts per page.
                page_number = request.GET.get('page')
                page_obj = paginator.get_page(page_number)
                return render(request, 'tramites/listar_clientes_tramites.html', {'clientes_tramites': page_obj})
                """
        if busqueda:
            clientes_tramites = Clientes_Tramites.objects.filter(
                Q (autos__icontains = busqueda) |
                Q (cliente_id__nombre_cliente__icontains= busqueda) |
                Q (tramite_id__nombre_tramite__icontains= busqueda) |
                Q (id__icontains = busqueda) |
                Q (cliente_id__id__icontains= busqueda)
            ).distinct()
        return render(request, 'tramites/listar_clientes_tramites.html', {'clientes_tramites':clientes_tramites})


#Clases para Cédulas#

class ListarCedulas(ListView):
    model = Cedulas1
    template_name = 'tramites/listar_cedulas.html'
    context_object_name = 'cedulas'
    queryset = Cedulas1.objects.all()
    

class EditarCedulas(UpdateView):
    model = Cedulas1
    template_name = 'tramites/modalCedulas.html'
    form_class = CedulasForm
    success_url = reverse_lazy ('tramites:listar_cedulas')


class CrearCedulas(CreateView):
    model = Cedulas1
    form_class =  CedulasForm
    template_name = 'tramites/crear_cedulas.html'
    success_url = reverse_lazy ('tramites:listar_cedulas')

class CrearModalCedulas(CreateView):
    model = Cedulas1
    template_name = 'tramites/modalcrearcedulas.html'
    form_class =  CedulasForm
    success_url = reverse_lazy ('tramites:listar_cedulas')

class EliminarCedulas(DeleteView):
    model = Cedulas1
    success_url = reverse_lazy ('tramites:listar_cedulas')


def buscar_cedulas(request):
        busqueda = request.GET.get("buscar")
        cedulas = Cedulas1.objects.all()
        Paginator
        """
        def listing(request):
                contact_list = Clientes_Tramites.objects.all()
                paginator = Paginator(contact_list, 2) # Show 25 contacts per page.
                page_number = request.GET.get('page')
                page_obj = paginator.get_page(page_number)
                return render(request, 'tramites/listar_clientes_tramites.html', {'clientes_tramites': page_obj})
                """
        if busqueda:
            cedulas = Cedulas1.objects.filter(
                Q (autos__icontains = busqueda) |
                Q (id__icontains = busqueda) |
                Q (casillero_id__casillero__icontains= busqueda) | 
                Q (casillero_id__co_titulares__icontains = busqueda) |
                Q (casillero_id__autorizados_a_retirar__icontains= busqueda)
            ).distinct()
        return render(request, 'tramites/listar_cedulas.html', {'cedulas':cedulas})

"""
def listar_busqueda(request):
    busqueda = request.GET.get("buscar")
    clientes = Clientes_Tramites.objects.all()
    if busqueda:
        clientes = Clientes_Tramites.objects.filter(
                Q( autos__icontains = busqueda)
            ).distinct()    
    return render(request, 'tramites/buscar_clientes_tramites.html', {'clientes' :clientes})



            def listing(request):
            contact_list = Clientes.objects.all()
            paginator = Paginator(contact_list, 2)

            page_number = request.GET.get('page')
            page_obj = paginator.get_page(page_number)
            return render(request, 'tramites:listar_clientes', {'page_obj': page_obj})

    """