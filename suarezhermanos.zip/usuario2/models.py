from cgi import MiniFieldStorage
from email.mime.image import MIMEImage
from enum import unique
import mimetypes
from unittest.util import _MAX_LENGTH
from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager
from django.forms import BooleanField, ImageField

# Create your models here.

class UsuarioManager(BaseUserManager):
    def create_user(self,mail,username,nombre,password= None):
        if not mail:
           raise ValueError('El usuario debe tener un correo electrónico')

        usuario = self.model(username = username, mail = self.normalize_email(mail), nombre = nombre)

        usuario.set_password(password)
        usuario.save()
        return usuario 

    def create_superuser(self, username, mail, nombre, password):
        usuario = self.create_user(mail, username = username, nombre = nombre, password=password)

        usuario.usuario_administrador = True
        usuario.save()
        return usuario         



class Usuario(AbstractBaseUser):
    username = models.CharField('Username/Mail', unique=True, max_length=100)
    mail = models.EmailField('mail', max_length=254, unique=True, null= True)
    nombre = models.CharField('Nombre', max_length=254, blank = True, null=True)
    usuario_activo = models.BooleanField(default=True) #usuarios que inician sesión
    usuario_administrador = models.BooleanField(default=False) #usuario en el administrador de django
    objects = UsuarioManager()
    """
        imagen = models.ImageField('Imgen de Perfil', upload_to='perfil/', height_field=None, width_field=None, max_length=200, blank= True, null = True)
    """

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['mail', 'nombre']

    def __str__(self):
        return f'{self.nombre}'

    def has_perm(self,perm,obj = None):
        return True
    
    def has_module_perms(self,app_label):
        return True


    @property
    def is_staff(self):
        return self.usuario_administrador
