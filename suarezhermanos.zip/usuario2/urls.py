from pipes import Template
from django.urls import path
from usuario2.views import ListadoUsuario, RegistrarUsuario
from django.contrib.auth.decorators import login_required
from django.views.generic import TemplateView

urlpatterns = [
    path('listar_usuarios/', login_required(ListadoUsuario.as_view()), name='listar_usuarios'),
    path('registrar_usuarios/', login_required(RegistrarUsuario.as_view()), name='registrar_usuarios'),
]

#urls vistas implicitas
urlpatterns += [
    path('inicio_usuarios/', login_required(
                                TemplateView.as_view(
                                    template_name = 'usuarios/listar_usuarios.html'
                                )
                            ), name='inicio_usuarios'),
]
