from django.apps import AppConfig


class Usuario2Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'usuario2'
